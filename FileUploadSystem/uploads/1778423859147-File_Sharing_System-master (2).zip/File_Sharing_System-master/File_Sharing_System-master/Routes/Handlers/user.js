let express = require('express');
var app = require('express').Router();
let path = require('path');

app.use(express.static(path.join(__dirname,'../../public')));
app.use(express.static(path.join(__dirname,'../../public/uploads')));

var auth=require('../../MiddleWares/auth');

let userController = require('../../Controllers/user');

app.get('/uploadFile',auth.checkSession, function(req,res) {
	res.render('uploadFile',{data : req.session,title : 'Upload File'});
})

app.get('/sendFileRecords',auth.checkSession, function(req,res) {
    res.render('sendFileRecords',{data : req.session,title : 'Send Files'});
})

app.get('/downloadSendFiles/:pro',auth.checkSession,function(req,res) {
    var filePath = '../../public/uploads/' + req.params.pro.toString();
    res.download(path.join(__dirname, filePath));
})

app.get('/recentFiles',auth.checkSession, function(req,res) {
    res.render('recentFiles',{data : req.session,title : 'Recent Files'});
})

app.get('/receivedFiles',auth.checkSession, function(req,res) {
    res.render('receivedFiles',{data : req.session,title : 'Received Files'});
})

// controllers //
//app.post('/uploadmultiple',auth.checkSession,userController.uploadmultiple);

//app.post('/Userupload',auth.checkSession,userController.Userupload);
//
//app.post('/uploadmultipleWithoutLogin',auth.checkSession,userController.uploadmultipleWithoutLogin);
//
app.post('/showSendFiles',auth.checkSession,userController.showSendFiles);

app.post('/deleteSendFiles',auth.checkSession,userController.deleteSendFiles);

app.post('/recentFilesData',auth.checkSession,userController.recentFiles);

app.post('/receivedFilesData',auth.checkSession,userController.receivedFiles);
app.post('/uploadmultiple',auth.checkSession,userController.uploadmultiple);

module.exports = app;