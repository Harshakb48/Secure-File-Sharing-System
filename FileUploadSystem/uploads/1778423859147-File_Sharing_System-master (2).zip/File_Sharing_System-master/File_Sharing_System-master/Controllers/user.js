const fs = require('fs');
let path = require('path');
var multer = require('../MiddleWares/multer');
var fileses = require('../Models/fileSchema');
const nodemailer = require("nodemailer");


// ✅ 1. UPLOAD FUNCTION
exports.uploadmultiple = (req, res) => {
    multer.upload(req, res, (err) => {
        if (err)
            res.send("format")
        else {
            const files = req.files
            if (files.length == 0)
                res.send('false');
            else {

                for (var i = 0; i < files.length; i++) {

                    var obj = new Object();
                    obj.to = req.body.title;
                    obj.from = req.session.email;
                    obj.message = req.body.message;
                    obj.fileName = files[i].filename;
                    obj.originalName = files[i].originalname;
                    obj.type = files[i].mimetype;
                    obj.entryDate = req.body.entryDate;

                    fileses.create(obj, function (error, result) {
                        if (error)
                            throw error;
                        else {
                            let transporter = nodemailer.createTransport({
                                service: "gmail",
                                auth: {
                                    user: "meghams6363@gmail.com",
                                    pass: "viftftsylbpbuzdi"
                                }
                            });

                            let mailOptions = {
                                from: "yourgmail@gmail.com",
                                to: obj.to,
                                subject: "File from Nilav App",
                                text: "You received a file from " + obj.from,
                                attachments: [
                                    {
                                        filename: obj.originalName,
                                        path: "./public/uploads/" + obj.fileName
                                    }
                                ]
                            };

                            transporter.sendMail(mailOptions, function (error, info) {
                                if (error) console.log("Mail Error:", error);
                                else console.log("Email sent:", info.response);
                            });
                        }
                    })
                }

                res.send('true');
            }
        }
    })
};


// ✅ 2. SHOW FILES (OUTSIDE!)
exports.showSendFiles = async (req, res) => {
    try {
        const data = await fileses.find({ from: req.session.email });
        res.json({ data: data });
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: err.message });
    }
};


// ✅ 3. DELETE FILE (OUTSIDE!)
exports.deleteSendFiles = async (req, res) => {
    try {
        await fileses.deleteOne({ _id: req.body._id });
        res.send("Deleted");
    } catch (err) {
        console.log(err);
        res.status(500).send(err);
    }
};

// ✅ 4. RECENT FILES
exports.recentFiles = async (req, res) => {
    try {
        const data = await fileses.find({ to: req.session.email });

        res.json({
            data: data
        });

    } catch (err) {
        console.log(err);
        res.status(500).json({ error: err.message });
    }
};
exports.receivedFiles = async (req, res) => {
    try {
        const data = await fileses.find({ to: req.session.email });
        res.json({ data: data });
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: err.message });
    }
};